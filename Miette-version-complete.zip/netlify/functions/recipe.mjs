export default async (request) => {
  const headers={"Content-Type":"application/json","Cache-Control":"no-store"};
  if(request.method!=="POST") return new Response(JSON.stringify({error:"Méthode non autorisée."}),{status:405,headers});
  const key=process.env.GEMINI_API_KEY;
  if(!key) return new Response(JSON.stringify({error:"Gemini n'est pas encore connecté. Le mode local est utilisé."}),{status:503,headers});
  try {
    const body=await request.json(), text=body?.text;
    if(typeof text!=="string" || text.trim().length<10 || text.length>30000) return new Response(JSON.stringify({error:"Le texte doit contenir entre 10 et 30 000 caractères."}),{status:400,headers});
    const prompt=`Tu es Miette, assistante culinaire francophone. Structure fidèlement cette recette. Ne crée jamais de quantités, d'ingrédients, de durées ou d'étapes absents. En cas de manque, laisse le champ vide et explique-le dans notes. Ne convertis pas les unités. Réponds en français, en JSON uniquement. Texte:\n${text}`;
    const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    const result=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":key},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:"application/json",responseSchema:{type:"OBJECT",properties:{title:{type:"STRING"},category:{type:"STRING",enum:["Apéritifs","Repas","Goûters","Desserts"]},prep:{type:"STRING"},cook:{type:"STRING"},temperature:{type:"STRING"},servings:{type:"STRING"},difficulty:{type:"STRING"},ingredients:{type:"ARRAY",items:{type:"STRING"}},steps:{type:"ARRAY",items:{type:"STRING"}},tags:{type:"ARRAY",items:{type:"STRING"}},equipment:{type:"ARRAY",items:{type:"STRING"}},notes:{type:"STRING"}},required:["title","category","prep","cook","temperature","servings","difficulty","ingredients","steps","tags","equipment","notes"]}}})});
    const payload=await result.json();
    if(!result.ok) return new Response(JSON.stringify({error:payload?.error?.message||"Gemini est momentanément indisponible."}),{status:502,headers});
    const raw=payload?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("");
    if(!raw) throw new Error("Réponse vide");
    return new Response(JSON.stringify({recipe:JSON.parse(raw)}),{status:200,headers});
  } catch(e) { return new Response(JSON.stringify({error:"Impossible d'organiser cette recette pour le moment."}),{status:500,headers}); }
};